document.addEventListener('DOMContentLoaded', function() {
    // Sample order data
    const orders = {
        current: [
            {
                id: 'AMH-2023-1567',
                date: '2023-11-15',
                status: 'processing',
                items: 3,
                total: 4599,
                products: [
                    {
                        name: 'Wireless Bluetooth Headphones',
                        image: 'https://m.media-amazon.com/images/I/61IJBsHm97L._SL1500_.jpg',
                        price: 1999,
                        quantity: 1
                    },
                    {
                        name: 'Smart Watch',
                        image: 'https://m.media-amazon.com/images/I/71YHjVXyR0L._SL1500_.jpg',
                        price: 2599,
                        quantity: 1
                    }
                ],
                address: {
                    name: 'John Doe',
                    street: '123 Main Street',
                    city: 'Bengaluru',
                    state: 'Karnataka',
                    pincode: '560001',
                    phone: '9876543210'
                }
            },
            {
                id: 'AMH-2023-1568',
                date: '2023-11-18',
                status: 'shipped',
                items: 2,
                total: 3499,
                products: [
                    {
                        name: 'Running Shoes',
                        image: 'https://m.media-amazon.com/images/I/71Kx5+ZJ+VL._SL1500_.jpg',
                        price: 2499,
                        quantity: 1
                    },
                    {
                        name: 'Sports T-Shirt',
                        image: 'https://m.media-amazon.com/images/I/71v1nZ5rA5L._UL1500_.jpg',
                        price: 999,
                        quantity: 1
                    }
                ],
                address: {
                    name: 'John Doe',
                    street: '123 Main Street',
                    city: 'Bengaluru',
                    state: 'Karnataka',
                    pincode: '560001',
                    phone: '9876543210'
                }
            }
        ],
        past: [
            {
                id: 'AMH-2023-1423',
                date: '2023-10-05',
                status: 'delivered',
                items: 1,
                total: 1299,
                products: [
                    {
                        name: 'Bluetooth Earbuds',
                        image: 'https://m.media-amazon.com/images/I/51HBom8xz7L._SL1500_.jpg',
                        price: 1299,
                        quantity: 1
                    }
                ],
                address: {
                    name: 'John Doe',
                    street: '123 Main Street',
                    city: 'Bengaluru',
                    state: 'Karnataka',
                    pincode: '560001',
                    phone: '9876543210'
                }
            },
            {
                id: 'AMH-2023-1387',
                date: '2023-09-22',
                status: 'delivered',
                items: 4,
                total: 8799,
                products: [
                    {
                        name: 'Smartphone',
                        image: 'https://m.media-amazon.com/images/I/71PvHfU+pwL._SL1500_.jpg',
                        price: 7999,
                        quantity: 1
                    },
                    {
                        name: 'Phone Case',
                        image: 'https://m.media-amazon.com/images/I/61mIUCd-37L._SL1500_.jpg',
                        price: 399,
                        quantity: 1
                    },
                    {
                        name: 'Screen Protector',
                        image: 'https://m.media-amazon.com/images/I/71o8Q5XJS5L._SL1500_.jpg',
                        price: 199,
                        quantity: 2
                    }
                ],
                address: {
                    name: 'John Doe',
                    street: '123 Main Street',
                    city: 'Bengaluru',
                    state: 'Karnataka',
                    pincode: '560001',
                    phone: '9876543210'
                }
            }
        ]
    };

    // DOM Elements
    const currentOrdersContainer = document.getElementById('currentOrders');
    const pastOrdersContainer = document.getElementById('pastOrders');
    const orderModal = document.getElementById('orderModal');
    const orderDetailsContainer = document.getElementById('orderDetails');
    const closeModal = document.querySelector('.close-modal');

    // Render Orders
    function renderOrders() {
        currentOrdersContainer.innerHTML = '';
        pastOrdersContainer.innerHTML = '';

        // Render current orders
        orders.current.forEach(order => {
            currentOrdersContainer.appendChild(createOrderCard(order));
        });

        // Render past orders
        orders.past.forEach(order => {
            pastOrdersContainer.appendChild(createOrderCard(order));
        });
    }

    // Create Order Card
    function createOrderCard(order) {
        const orderCard = document.createElement('div');
        orderCard.className = 'order-card';
        orderCard.setAttribute('data-id', order.id);

        // Status class
        const statusClass = `status-${order.status}`;

        // Format date
        const formattedDate = new Date(order.date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });

        // Create card HTML
        orderCard.innerHTML = `
            <div class="order-header">
                <div>
                    <div class="order-id">Order #${order.id}</div>
                    <div class="order-date">Placed on ${formattedDate}</div>
                </div>
                <div class="order-status ${statusClass}">${order.status.charAt(0).toUpperCase() + order.status.slice(1)}</div>
            </div>
            <div class="order-summary">
                <div class="order-summary-item">
                    <span class="order-summary-label">Items</span>
                    <span class="order-summary-value">${order.items}</span>
                </div>
                <div class="order-summary-item">
                    <span class="order-summary-label">Total Amount</span>
                    <span class="order-summary-value">₹${order.total.toLocaleString()}</span>
                </div>
                <div class="order-summary-item">
                    <span class="order-summary-label">Payment</span>
                    <span class="order-summary-value">Paid</span>
                </div>
            </div>
            <div class="order-products">
                ${order.products.map(product => `
                    <img src="${product.image}" alt="${product.name}" class="order-product-img">
                `).join('')}
            </div>
            <div class="order-actions">
                <button class="view-details-btn">View Details</button>
            </div>
        `;

        // Add click event to view details
        orderCard.addEventListener('click', function() {
            viewOrderDetails(order.id);
        });

        return orderCard;
    }

    // View Order Details
    function viewOrderDetails(orderId) {
        // Find the order
        let order;
        for (const o of [...orders.current, ...orders.past]) {
            if (o.id === orderId) {
                order = o;
                break;
            }
        }

        if (!order) return;

        // Format date
        const formattedDate = new Date(order.date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        // Status class
        const statusClass = `status-${order.status}`;

        // Create order details HTML
        orderDetailsContainer.innerHTML = `
            <div class="order-details-header">
                <h2>Order #${order.id}</h2>
                <p>Placed on ${formattedDate}</p>
                <div class="order-status ${statusClass}">${order.status.charAt(0).toUpperCase() + order.status.slice(1)}</div>
            </div>
            
            <div class="order-details-products">
                <h3>Products (${order.items})</h3>
                ${order.products.map(product => `
                    <div class="order-product-item">
                        <img src="${product.image}" alt="${product.name}" class="order-product-img-lg">
                        <div class="order-product-info">
                            <h3>${product.name}</h3>
                            <div class="order-product-price">₹${product.price.toLocaleString()}</div>
                            <div class="order-product-quantity">Quantity: ${product.quantity}</div>
                        </div>
                    </div>
                `).join('')}
            </div>
            
            <div class="order-details-summary">
                <h3>Order Summary</h3>
                <div class="summary-row">
                    <span class="summary-label">Subtotal</span>
                    <span class="summary-value">₹${order.total.toLocaleString()}</span>
                </div>
                <div class="summary-row">
                    <span class="summary-label">Shipping</span>
                    <span class="summary-value">FREE</span>
                </div>
                <div class="summary-row">
                    <span class="summary-label">Tax</span>
                    <span class="summary-value">₹${Math.round(order.total * 0.18).toLocaleString()}</span>
                </div>
                <div class="summary-row summary-total">
                    <span class="summary-label">Total</span>
                    <span class="summary-value">₹${Math.round(order.total * 1.18).toLocaleString()}</span>
                </div>
            </div>
            
            <div class="order-details-address">
                <h3 class="address-title">Shipping Address</h3>
                <div class="address-details">
                    <p>${order.address.name}</p>
                    <p>${order.address.street}</p>
                    <p>${order.address.city}, ${order.address.state} - ${order.address.pincode}</p>
                    <p>Phone: ${order.address.phone}</p>
                </div>
            </div>
        `;

        // Show modal
        orderModal.style.display = 'block';
    }

    // Close Modal
    closeModal.addEventListener('click', function() {
        orderModal.style.display = 'none';
    });

    // Close modal when clicking outside
    window.addEventListener('click', function(e) {
        if (e.target === orderModal) {
            orderModal.style.display = 'none';
        }
    });

    // Initialize
    renderOrders();
});