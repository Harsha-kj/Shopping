document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const loginForm = document.getElementById('loginForm');
    const loginId = document.getElementById('loginId');
    const password = document.getElementById('password');
    const togglePassword = document.getElementById('togglePassword');
    const loginBtn = document.getElementById('loginBtn');
    const loginIdError = document.getElementById('loginIdError');
    const passwordError = document.getElementById('passwordError');

    // Toggle Password Visibility
    togglePassword.addEventListener('click', function() {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.classList.toggle('fa-eye-slash');
    });

    // Form Validation
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Reset error messages
        loginIdError.textContent = '';
        passwordError.textContent = '';

        let isValid = true;

        // Validate Login ID (Email or Mobile)
        if (loginId.value.trim() === '') {
            loginIdError.textContent = 'Email or mobile number is required';
            isValid = false;
        } else {
            // Check if it's an email
            const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(loginId.value);
            // Check if it's a mobile number
            const isMobile = /^\d{10}$/.test(loginId.value);
            
            if (!isEmail && !isMobile) {
                loginIdError.textContent = 'Please enter a valid email or 10-digit mobile number';
                isValid = false;
            }
        }

        // Validate Password
        if (password.value.trim() === '') {
            passwordError.textContent = 'Password is required';
            isValid = false;
        } else if (password.value.length < 8) {
            passwordError.textContent = 'Password must be at least 8 characters';
            isValid = false;
        }

        // If form is valid, submit it
        if (isValid) {
            submitForm();
        }
    });

    // Form Submission
    function submitForm() {
        // Show loading state
        loginBtn.classList.add('loading');
        
        // Simulate API call (replace with actual fetch/AJAX call)
        setTimeout(() => {
            // Hide loading state
            loginBtn.classList.remove('loading');
            
            // Show success message (in a real app, you would redirect)
            alert('Login successful! Redirecting...');
            
            // In a real app, you would redirect here
            // window.location.href = 'dashboard.html';
        }, 1500);
    }

    // Initialize floating labels
    document.querySelectorAll('.input-container input').forEach(input => {
        // Trigger the floating label on page load if there's a value
        if (input.value) {
            input.dispatchEvent(new Event('input'));
        }
        
        // Add input event to handle floating labels
        input.addEventListener('input', function() {
            const label = this.nextElementSibling;
            if (this.value) {
                label.style.top = '-10px';
                label.style.left = '10px';
                label.style.fontSize = '0.8rem';
                label.style.color = 'var(--primary-color)';
            } else {
                label.style.top = '18px';
                label.style.left = '15px';
                label.style.fontSize = '1rem';
                label.style.color = 'var(--gray-color)';
            }
        });
    });
});