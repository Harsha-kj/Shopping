document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const emailForm = document.getElementById('emailForm');
    const otpForm = document.getElementById('otpForm');
    const newPasswordForm = document.getElementById('newPasswordForm');
    const steps = document.querySelectorAll('.step');
    const resendLink = document.getElementById('resendLink');
    const otpInputs = document.querySelectorAll('.otp-input');
    const togglePasswordIcons = document.querySelectorAll('.toggle-password');
    const newPasswordInput = document.getElementById('newPassword');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const strengthBar = document.querySelector('.strength-bar');
    const strengthText = document.querySelector('.strength-text span');
    
    let countdownInterval;
    let countdown = 30;

    // Step 1: Email Submission
    emailForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const emailError = document.getElementById('emailError');
        
        // Simple validation
        if (!validateEmail(email)) {
            emailError.textContent = 'Please enter a valid email address';
            return;
        }
        
        // Show loading state
        const btn = this.querySelector('.login-btn');
        btn.classList.add('loading');
        
        // Simulate API call
        setTimeout(() => {
            btn.classList.remove('loading');
            goToStep(2);
            startCountdown();
            
            // In a real app, you would send the email to your backend
            console.log('Email submitted:', email);
        }, 1500);
    });
    
    // Step 2: OTP Verification
    otpForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const otpError = document.getElementById('otpError');
        const otp = Array.from(otpInputs).map(input => input.value).join('');
        
        if (otp.length !== 6) {
            otpError.textContent = 'Please enter the 6-digit code';
            return;
        }
        
        // Show loading state
        const btn = this.querySelector('.login-btn');
        btn.classList.add('loading');
        
        // Simulate API verification
        setTimeout(() => {
            btn.classList.remove('loading');
            goToStep(3);
            
            // In a real app, you would verify the OTP with your backend
            console.log('OTP submitted:', otp);
        }, 1500);
    });
    
    // Step 3: New Password
    newPasswordForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const newPassword = newPasswordInput.value;
        const confirmPassword = confirmPasswordInput.value;
        const newPasswordError = document.getElementById('newPasswordError');
        const confirmPasswordError = document.getElementById('confirmPasswordError');
        
        // Reset errors
        newPasswordError.textContent = '';
        confirmPasswordError.textContent = '';
        
        // Validate password
        if (newPassword.length < 8) {
            newPasswordError.textContent = 'Password must be at least 8 characters';
            return;
        }
        
        if (newPassword !== confirmPassword) {
            confirmPasswordError.textContent = 'Passwords do not match';
            return;
        }
        
        // Show loading state
        const btn = this.querySelector('.login-btn');
        btn.classList.add('loading');
        
        // Simulate password reset
        setTimeout(() => {
            btn.classList.remove('loading');
            showSuccessMessage();
            
            // In a real app, you would send the new password to your backend
            console.log('New password submitted:', newPassword);
        }, 1500);
    });
    
    // OTP Input Handling
    otpInputs.forEach((input, index) => {
        input.addEventListener('input', function() {
            if (this.value.length === 1 && index < otpInputs.length - 1) {
                otpInputs[index + 1].focus();
            }
        });
        
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Backspace' && this.value.length === 0 && index > 0) {
                otpInputs[index - 1].focus();
            }
        });
    });
    
    // Resend OTP
    resendLink.addEventListener('click', function(e) {
        e.preventDefault();
        startCountdown();
        
        // In a real app, you would request a new OTP from your backend
        console.log('Resending OTP...');
    });
    
    // Toggle Password Visibility
    togglePasswordIcons.forEach(icon => {
        icon.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input');
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    });
    
    // Password Strength Checker
    newPasswordInput.addEventListener('input', function() {
        const strength = checkPasswordStrength(this.value);
        updateStrengthIndicator(strength);
    });
    
    // Helper Functions
    function goToStep(stepNumber) {
        steps.forEach(step => step.classList.remove('active'));
        document.getElementById(`step${stepNumber}`).classList.add('active');
    }
    
    function startCountdown() {
        clearInterval(countdownInterval);
        countdown = 30;
        updateResendText();
        
        countdownInterval = setInterval(() => {
            countdown--;
            updateResendText();
            
            if (countdown <= 0) {
                clearInterval(countdownInterval);
            }
        }, 1000);
    }
    
    function updateResendText() {
        const resendContainer = document.querySelector('.resend-code');
        if (countdown > 0) {
            resendContainer.innerHTML = `Didn't receive code? <a href="#" id="resendLink">Resend</a> (${countdown}s)`;
            document.getElementById('resendLink').addEventListener('click', function(e) {
                e.preventDefault();
                startCountdown();
            });
        } else {
            resendContainer.innerHTML = `Didn't receive code? <a href="#" id="resendLink">Resend</a>`;
            document.getElementById('resendLink').addEventListener('click', function(e) {
                e.preventDefault();
                startCountdown();
            });
        }
    }
    
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    function checkPasswordStrength(password) {
        let strength = 0;
        
        // Length check
        if (password.length >= 8) strength += 1;
        if (password.length >= 12) strength += 1;
        
        // Character type checks
        if (/[A-Z]/.test(password)) strength += 1;
        if (/[0-9]/.test(password)) strength += 1;
        if (/[^A-Za-z0-9]/.test(password)) strength += 1;
        
        return Math.min(strength, 5); // Cap at 5
    }
    
    function updateStrengthIndicator(strength) {
        const width = (strength / 5) * 100;
        strengthBar.style.width = `${width}%`;
        
        // Update color and text based on strength
        if (strength <= 2) {
            strengthBar.style.backgroundColor = '#dc3545';
            strengthText.textContent = 'Weak';
        } else if (strength <= 3) {
            strengthBar.style.backgroundColor = '#fd7e14';
            strengthText.textContent = 'Medium';
        } else if (strength <= 4) {
            strengthBar.style.backgroundColor = '#ffc107';
            strengthText.textContent = 'Strong';
        } else {
            strengthBar.style.backgroundColor = '#28a745';
            strengthText.textContent = 'Very Strong';
        }
    }
    
    function showSuccessMessage() {
        const successHTML = `
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <h3>Password Reset Successful!</h3>
                <p>Your password has been updated successfully. You can now login with your new password.</p>
            </div>
        `;
        
        steps[2].innerHTML = successHTML;
        
        // Redirect to login after 3 seconds
        setTimeout(() => {
            window.location.href = '/login/login.html';
        }, 3000);
    }
});