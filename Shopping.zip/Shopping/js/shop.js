document.addEventListener('DOMContentLoaded', function() {
    // Sample product data
    const products = [
        {
            id: 1,
            name: "iPhone 13 Pro Max",
            category: "mobiles",
            price: 109999,
            originalPrice: 129900,
            images: ["https://m.media-amazon.com/images/I/61IJBsHm97L._SL1500_.jpg"],
            rating: 4.5,
            reviews: 1245,
            description: "The iPhone 13 Pro Max is Apple's biggest phone with a 6.7-inch screen, A15 Bionic chip, and triple-camera system with Night mode and Deep Fusion.",
            specs: [
                "6.7-inch Super Retina XDR display",
                "A15 Bionic chip with 6-core CPU, 5-core GPU, and 16-core Neural Engine",
                "Pro camera system with 12MP Telephoto, Wide, and Ultra Wide cameras",
                "Face ID for secure authentication",
                "5G capable",
                "Up to 28 hours video playback"
            ]
        },
        {
            id: 2,
            name: "Samsung Galaxy S22 Ultra",
            category: "mobiles",
            price: 89999,
            originalPrice: 109999,
            images: ["https://m.media-amazon.com/images/I/71PvHfU+pwL._SL1500_.jpg"],
            rating: 4.7,
            reviews: 987,
            description: "The Samsung Galaxy S22 Ultra combines the best of Galaxy S and Note series with S Pen integration, pro-grade camera, and powerful performance.",
            specs: [
                "6.8-inch Dynamic AMOLED 2X display",
                "Exynos 2200 / Snapdragon 8 Gen 1 processor",
                "108MP main camera with 10x optical zoom",
                "Built-in S Pen with 2.8ms latency",
                "5G capable",
                "5000mAh battery with fast charging"
            ]
        },
        {
            id: 3,
            name: "OnePlus 10 Pro",
            category: "mobiles",
            price: 66999,
            originalPrice: 71999,
            images: ["https://m.media-amazon.com/images/I/61mIUCd-37L._SL1500_.jpg"],
            rating: 4.3,
            reviews: 654,
            description: "The OnePlus 10 Pro features Hasselblad Camera for Mobile, 80W SuperVOOC charging, and Snapdragon 8 Gen 1 processor.",
            specs: [
                "6.7-inch Fluid AMOLED display with LTPO 2.0",
                "Snapdragon 8 Gen 1 processor",
                "Hasselblad Camera with 48MP main sensor",
                "80W SuperVOOC fast charging",
                "5G capable",
                "OxygenOS based on Android 12"
            ]
        },
        {
            id: 4,
            name: "Sony WH-1000XM4 Headphones",
            category: "electronics",
            price: 24990,
            originalPrice: 29990,
            images: ["https://m.media-amazon.com/images/I/71o8Q5XJS5L._SL1500_.jpg"],
            rating: 4.8,
            reviews: 2345,
            description: "Industry-leading noise cancellation with Dual Noise Sensor technology, touch controls and up to 30-hour battery life.",
            specs: [
                "Industry-leading noise cancellation",
                "Dual Noise Sensor technology",
                "30-hour battery life with quick charging",
                "Touch controls",
                "Built-in Alexa and Google Assistant",
                "Hi-Res Audio compatible"
            ]
        },
        {
            id: 5,
            name: "Apple Watch Series 7",
            category: "electronics",
            price: 41900,
            originalPrice: 45900,
            images: ["https://m.media-amazon.com/images/I/71YHjVXyR0L._SL1500_.jpg"],
            rating: 4.6,
            reviews: 1789,
            description: "Apple Watch Series 7 features a larger, more advanced display, faster charging, and the most durable Apple Watch yet.",
            specs: [
                "45mm or 41mm case size",
                "Always-On Retina display",
                "Blood oxygen and ECG apps",
                "Water resistant 50 meters",
                "GPS + Cellular options",
                "WatchOS 8"
            ]
        },
        {
            id: 6,
            name: "Nike Air Max 270",
            category: "shoes",
            price: 10995,
            originalPrice: 12995,
            images: ["https://m.media-amazon.com/images/I/71Kx5+ZJ+VL._SL1500_.jpg"],
            rating: 4.4,
            reviews: 876,
            description: "The Nike Air Max 270 delivers an exaggerated Air unit underheel for all-day comfort and a bold look inspired by Air Max icons.",
            specs: [
                "Breathable mesh upper",
                "Foam midsole",
                "Rubber outsole",
                "Max Air unit in heel",
                "Available in multiple colors",
                "Lace-up closure"
            ]
        },
        {
            id: 7,
            name: "Adidas T-Shirt",
            category: "fashion",
            price: 999,
            originalPrice: 1499,
            images: ["https://m.media-amazon.com/images/I/71v1nZ5rA5L._UL1500_.jpg"],
            rating: 4.2,
            reviews: 432,
            description: "Classic adidas T-shirt with the iconic 3-Stripes design on the sleeves for a sporty look and everyday comfort.",
            specs: [
                "100% cotton",
                "Regular fit",
                "Ribbed crewneck",
                "Short sleeves",
                "Machine washable",
                "Available in multiple colors"
            ]
        },
        {
            id: 8,
            name: "Dell XPS 13 Laptop",
            category: "electronics",
            price: 124990,
            originalPrice: 139990,
            images: ["https://m.media-amazon.com/images/I/71LXY5Q1wJL._SL1500_.jpg"],
            rating: 4.7,
            reviews: 765,
            description: "The Dell XPS 13 is a premium ultrabook with InfinityEdge display, 11th Gen Intel Core processors, and stunning design.",
            specs: [
                "13.4-inch FHD+ or UHD+ InfinityEdge display",
                "11th Gen Intel Core i5/i7 processors",
                "Up to 32GB RAM",
                "Up to 2TB SSD storage",
                "Thunderbolt 4 ports",
                "Windows 11 Pro"
            ]
        },
        {
            id: 9,
            name: "Boat Airdopes 441",
            category: "electronics",
            price: 1999,
            originalPrice: 2999,
            images: ["https://m.media-amazon.com/images/I/51HBom8xz7L._SL1500_.jpg"],
            rating: 4.1,
            reviews: 5432,
            description: "boAt Airdopes 441 are truly wireless earbuds with 6mm drivers, Bluetooth v5.0, and up to 6 hours playback.",
            specs: [
                "6mm drivers",
                "Bluetooth v5.0",
                "6 hours playback",
                "IPX7 water resistance",
                "Touch controls",
                "Quick charge (75 mins in 5 mins)"
            ]
        },
        {
            id: 10,
            name: "Samsung 55-inch QLED TV",
            category: "electronics",
            price: 64990,
            originalPrice: 79990,
            images: ["https://m.media-amazon.com/images/I/71RxCmvnrbL._SL1500_.jpg"],
            rating: 4.6,
            reviews: 1234,
            description: "Samsung 55-inch QLED 4K Smart TV with Quantum Dot technology and Object Tracking Sound.",
            specs: [
                "55-inch QLED display",
                "4K UHD resolution",
                "Quantum Dot technology",
                "Object Tracking Sound",
                "Smart TV with Tizen OS",
                "Multiple HDMI and USB ports"
            ]
        },
        {
            id: 11,
            name: "Puma Running Shoes",
            category: "shoes",
            price: 2999,
            originalPrice: 3999,
            images: ["https://m.media-amazon.com/images/I/61yM+LKX0AL._UL1500_.jpg"],
            rating: 4.3,
            reviews: 876,
            description: "Puma running shoes with cushioned midsole and breathable mesh upper for maximum comfort.",
            specs: [
                "Breathable mesh upper",
                "Cushioned midsole",
                "Rubber outsole",
                "Lace-up closure",
                "Lightweight design",
                "Available in multiple colors"
            ]
        },
        {
            id: 12,
            name: "Mi Power Bank 20000mAh",
            category: "electronics",
            price: 1499,
            originalPrice: 1999,
            images: ["https://m.media-amazon.com/images/I/61usDfE5+BL._SL1500_.jpg"],
            rating: 4.2,
            reviews: 4321,
            description: "Mi Power Bank with 20000mAh capacity, dual input/output ports, and 18W fast charging.",
            specs: [
                "20000mAh capacity",
                "Dual input/output ports",
                "18W fast charging",
                "LED power indicator",
                "Multiple protection features",
                "Compact design"
            ]
        }
    ];

    // DOM Elements
    const allProductsGrid = document.getElementById('all-products');
    const searchBar = document.querySelector('.search-bar');
    const searchResults = document.querySelector('.search-results');
    const cartCount = document.querySelector('.cart-count');
    const productModal = document.getElementById('productModal');
    const closeModal = document.querySelector('.close-modal');
    const modalProductImage = document.getElementById('modalProductImage');
    const modalProductName = document.getElementById('modalProductName');
    const modalProductPrice = document.getElementById('modalProductPrice');
    const modalProductOriginalPrice = document.getElementById('modalProductOriginalPrice');
    const modalProductDiscount = document.getElementById('modalProductDiscount');
    const modalProductDescription = document.getElementById('modalProductDescription');
    const modalProductSpecs = document.getElementById('modalProductSpecs');

    // Cart items
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    updateCartCount();

    // Initialize the page
    function init() {
        renderProducts(products, allProductsGrid);
        setupEventListeners();
    }

    // Render products to the grid
    function renderProducts(products, gridElement) {
        gridElement.innerHTML = '';
        
        products.forEach(product => {
            const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
            
            const productCard = document.createElement('div');
            productCard.className = 'product-card';
            productCard.innerHTML = `
                <div class="product-image">
                    <img src="${product.images[0]}" alt="${product.name}">
                </div>
                <div class="product-info">
                    <h3 class="product-name">${product.name}</h3>
                    <div class="product-price">
                        <span class="current-price">₹${product.price.toLocaleString()}</span>
                        <span class="original-price">₹${product.originalPrice.toLocaleString()}</span>
                        <span class="discount">${discount}% off</span>
                    </div>
                    <div class="product-rating">
                        <div class="stars">
                            ${renderStars(product.rating)}
                        </div>
                        <span class="reviews">(${product.reviews.toLocaleString()})</span>
                    </div>
                    <div class="product-actions">
                        <button class="add-to-cart-btn" data-id="${product.id}">
                            <i class="fas fa-shopping-cart"></i> Add to Cart
                        </button>
                        <button class="buy-now-btn" data-id="${product.id}">
                            <i class="fas fa-bolt"></i> Buy Now
                        </button>
                    </div>
                </div>
            `;
            
            gridElement.appendChild(productCard);
        });
    }

    // Render star ratings
    function renderStars(rating) {
        let stars = '';
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        
        for (let i = 0; i < fullStars; i++) {
            stars += '<i class="fas fa-star"></i>';
        }
        
        if (hasHalfStar) {
            stars += '<i class="fas fa-star-half-alt"></i>';
        }
        
        const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        for (let i = 0; i < emptyStars; i++) {
            stars += '<i class="far fa-star"></i>';
        }
        
        return stars;
    }

    // Setup event listeners
    function setupEventListeners() {
        // Search functionality
        searchBar.addEventListener('input', handleSearch);
        
        // Add to cart buttons
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('add-to-cart-btn') || e.target.parentElement.classList.contains('add-to-cart-btn')) {
                const btn = e.target.classList.contains('add-to-cart-btn') ? e.target : e.target.parentElement;
                const productId = parseInt(btn.getAttribute('data-id'));
                addToCart(productId);
            }
            
            if (e.target.classList.contains('buy-now-btn') || e.target.parentElement.classList.contains('buy-now-btn')) {
                const btn = e.target.classList.contains('buy-now-btn') ? e.target : e.target.parentElement;
                const productId = parseInt(btn.getAttribute('data-id'));
                buyNow(productId);
            }
            
            if (e.target.classList.contains('product-name') || e.target.classList.contains('product-image')) {
                const productCard = e.target.closest('.product-card');
                const productName = productCard.querySelector('.product-name').textContent;
                const product = products.find(p => p.name === productName);
                if (product) {
                    openProductModal(product);
                }
            }
        });
        
        // Modal close
        closeModal.addEventListener('click', () => {
            productModal.style.display = 'none';
        });
        
        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === productModal) {
                productModal.style.display = 'none';
            }
        });
    }

    // Handle search
    function handleSearch() {
        const searchTerm = searchBar.value.toLowerCase();
        
        if (searchTerm.length < 2) {
            searchResults.classList.remove('active');
            return;
        }
        
        const results = products.filter(product => 
            product.name.toLowerCase().includes(searchTerm) ||
            product.category.toLowerCase().includes(searchTerm) ||
            product.description.toLowerCase().includes(searchTerm)
        ).slice(0, 5);
        
        if (results.length > 0) {
            searchResults.innerHTML = results.map(product => `
                <div class="search-result-item" data-id="${product.id}">
                    <div class="search-result-name">${product.name}</div>
                    <div class="search-result-category">${product.category}</div>
                </div>
            `).join('');
            
            searchResults.classList.add('active');
            
            // Add click event to search results
            document.querySelectorAll('.search-result-item').forEach(item => {
                item.addEventListener('click', () => {
                    const productId = parseInt(item.getAttribute('data-id'));
                    const product = products.find(p => p.id === productId);
                    if (product) {
                        openProductModal(product);
                        searchResults.classList.remove('active');
                        searchBar.value = '';
                    }
                });
            });
        } else {
            searchResults.innerHTML = '<div class="search-result-item">No results found</div>';
            searchResults.classList.add('active');
        }
    }

    // Add to cart
    function addToCart(productId) {
        const product = products.find(p => p.id === productId);
        
        if (!product) return;
        
        const existingItem = cartItems.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cartItems.push({
                ...product,
                quantity: 1
            });
        }
        
        updateCartCount();
        saveCartToLocalStorage();
        
        // Show notification
        showNotification(`${product.name} added to cart!`);
    }

    // Buy now
    function buyNow(productId) {
        addToCart(productId);
        // In a real app, we would redirect to checkout page
        alert('Proceeding to checkout with this item!');
    }

    // Update cart count
    function updateCartCount() {
        const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
        cartCount.textContent = totalItems;
    }

    // Save cart to localStorage
    function saveCartToLocalStorage() {
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
    }

    // Show notification
    function showNotification(message) {
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Open product modal
    function openProductModal(product) {
        const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
        
        modalProductImage.src = product.images[0];
        modalProductName.textContent = product.name;
        modalProductPrice.textContent = `₹${product.price.toLocaleString()}`;
        modalProductOriginalPrice.textContent = `₹${product.originalPrice.toLocaleString()}`;
        modalProductDiscount.textContent = `${discount}% off`;
        modalProductDescription.textContent = product.description;
        
        // Render specs
        modalProductSpecs.innerHTML = `
            <h3>Specifications</h3>
            <ul>
                ${product.specs.map(spec => `<li>${spec}</li>`).join('')}
            </ul>
        `;
        
        // Render thumbnails
        const thumbnailsContainer = document.querySelector('.product-thumbnails');
        thumbnailsContainer.innerHTML = '';
        
        product.images.forEach((image, index) => {
            const thumbnail = document.createElement('img');
            thumbnail.src = image;
            thumbnail.alt = `${product.name} thumbnail ${index + 1}`;
            thumbnail.addEventListener('click', () => {
                modalProductImage.src = image;
            });
            thumbnailsContainer.appendChild(thumbnail);
        });
        
        // Update add to cart and buy now buttons
        const addToCartBtn = document.querySelector('.modal-content .add-to-cart-btn');
        const buyNowBtn = document.querySelector('.modal-content .buy-now-btn');
        
        addToCartBtn.setAttribute('data-id', product.id);
        buyNowBtn.setAttribute('data-id', product.id);
        
        productModal.style.display = 'block';
    }

    // Initialize the app
    init();
});