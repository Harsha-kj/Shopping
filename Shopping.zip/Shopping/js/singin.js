document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const signinForm = document.getElementById('signinForm');
    const firstName = document.getElementById('firstName');
    const lastName = document.getElementById('lastName');
    const mobile = document.getElementById('mobile');
    const email = document.getElementById('email');
    const address = document.getElementById('address');
    const pincode = document.getElementById('pincode');
    const password = document.getElementById('password');
    const togglePassword = document.getElementById('togglePassword');
    const signinBtn = document.getElementById('signinBtn');

    // Error Elements
    const firstNameError = document.getElementById('firstNameError');
    const lastNameError = document.getElementById('lastNameError');
    const mobileError = document.getElementById('mobileError');
    const emailError = document.getElementById('emailError');
    const addressError = document.getElementById('addressError');
    const pincodeError = document.getElementById('pincodeError');
    const passwordError = document.getElementById('passwordError');

    // Password Requirement Elements
    const lengthReq = document.getElementById('lengthReq');
    const specialReq = document.getElementById('specialReq');
    const numberReq = document.getElementById('numberReq');
    const upperReq = document.getElementById('upperReq');

    // Toggle Password Visibility
    togglePassword.addEventListener('click', function() {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.classList.toggle('fa-eye-slash');
    });

    // Validate Mobile Number (only numbers and 10 digits)
    mobile.addEventListener('input', function() {
        this.value = this.value.replace(/[^0-9]/g, '');
        if (this.value.length > 10) {
            this.value = this.value.slice(0, 10);
        }
    });

    // Validate Pincode (only numbers and 6 digits)
    pincode.addEventListener('input', function() {
        this.value = this.value.replace(/[^0-9]/g, '');
        if (this.value.length > 6) {
            this.value = this.value.slice(0, 6);
        }
    });

    // Validate Password in real-time
    password.addEventListener('input', validatePassword);

    function validatePassword() {
        const value = password.value;
        let isValid = true;

        // Check length (min 8 characters)
        if (value.length >= 8) {
            lengthReq.classList.add('valid');
        } else {
            lengthReq.classList.remove('valid');
            isValid = false;
        }

        // Check for special character
        if (/[!@#$%^&*(),.?":{}|<>]/.test(value)) {
            specialReq.classList.add('valid');
        } else {
            specialReq.classList.remove('valid');
            isValid = false;
        }

        // Check for number
        if (/\d/.test(value)) {
            numberReq.classList.add('valid');
        } else {
            numberReq.classList.remove('valid');
            isValid = false;
        }

        // Check for uppercase letter
        if (/[A-Z]/.test(value)) {
            upperReq.classList.add('valid');
        } else {
            upperReq.classList.remove('valid');
            isValid = false;
        }

        return isValid;
    }

    // Form Validation
    signinForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Reset error messages
        firstNameError.textContent = '';
        lastNameError.textContent = '';
        mobileError.textContent = '';
        emailError.textContent = '';
        addressError.textContent = '';
        pincodeError.textContent = '';
        passwordError.textContent = '';

        let isValid = true;

        // Validate First Name
        if (firstName.value.trim() === '') {
            firstNameError.textContent = 'First name is required';
            isValid = false;
        }

        // Validate Last Name
        if (lastName.value.trim() === '') {
            lastNameError.textContent = 'Last name is required';
            isValid = false;
        }

        // Validate Mobile
        if (mobile.value.trim() === '') {
            mobileError.textContent = 'Mobile number is required';
            isValid = false;
        } else if (mobile.value.length !== 10) {
            mobileError.textContent = 'Mobile number must be 10 digits';
            isValid = false;
        }

        // Validate Email
        if (email.value.trim() === '') {
            emailError.textContent = 'Email is required';
            isValid = false;
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
            emailError.textContent = 'Please enter a valid email';
            isValid = false;
        }

        // Validate Address
        if (address.value.trim() === '') {
            addressError.textContent = 'Address is required';
            isValid = false;
        }

        // Validate Pincode
        if (pincode.value.trim() === '') {
            pincodeError.textContent = 'Pincode is required';
            isValid = false;
        } else if (pincode.value.length !== 6) {
            pincodeError.textContent = 'Pincode must be 6 digits';
            isValid = false;
        }

        // Validate Password
        if (password.value.trim() === '') {
            passwordError.textContent = 'Password is required';
            isValid = false;
        } else if (!validatePassword()) {
            passwordError.textContent = 'Password does not meet requirements';
            isValid = false;
        }

        // If form is valid, submit it
        if (isValid) {
            submitForm();
        }
    });

    // Form Submission
    function submitForm() {
        // Show loading state
        signinBtn.classList.add('loading');
        
        // Simulate API call (replace with actual fetch/AJAX call)
        setTimeout(() => {
            // Hide loading state
            signinBtn.classList.remove('loading');
            
            // Show success message (in a real app, you would redirect or show a success message)
            alert('Registration successful!');
            
            // Reset form
            signinForm.reset();
            
            // Reset floating labels
            document.querySelectorAll('.input-container input').forEach(input => {
                input.dispatchEvent(new Event('input'));
            });
            
            // Reset password requirements
            lengthReq.classList.remove('valid');
            specialReq.classList.remove('valid');
            numberReq.classList.remove('valid');
            upperReq.classList.remove('valid');
        }, 2000);
    }

    // Initialize floating labels
    document.querySelectorAll('.input-container input').forEach(input => {
        // Trigger the floating label on page load if there's a value
        if (input.value) {
            input.dispatchEvent(new Event('input'));
        }
        
        // Add input event to handle floating labels
        input.addEventListener('input', function() {
            const label = this.nextElementSibling;
            if (this.value) {
                label.style.top = '-10px';
                label.style.left = '10px';
                label.style.fontSize = '0.8rem';
                label.style.color = 'var(--primary-color)';
            } else {
                label.style.top = '18px';
                label.style.left = '15px';
                label.style.fontSize = '1rem';
                label.style.color = 'var(--gray-color)';
            }
        });
    });
});