document.getElementById('checkout-form').addEventListener('submit', function (e) {
  e.preventDefault();

  // Optionally, you could validate here.

  const popup = document.getElementById('success-popup');
  popup.style.display = 'flex';
});

function closePopup() {
  document.getElementById('success-popup').style.display = 'none';
}
