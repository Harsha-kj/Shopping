document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const cartEmpty = document.getElementById('cartEmpty');
    const cartWithItems = document.getElementById('cartWithItems');
    const cartItemsContainer = document.getElementById('cartItems');
    const cartCount = document.querySelector('.cart-count');
    const cartSubtotal = document.getElementById('cartSubtotal');
    const cartTax = document.getElementById('cartTax');
    const cartGrandTotal = document.getElementById('cartGrandTotal');
    const clearCartBtn = document.getElementById('clearCartBtn');
    const checkoutBtn = document.getElementById('checkoutBtn');

    // Load cart items from localStorage
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    updateCartUI();

    // Update cart UI
    function updateCartUI() {
        updateCartCount();
        
        if (cartItems.length === 0) {
            cartEmpty.style.display = 'flex';
            cartWithItems.style.display = 'none';
            return;
        }
        
        cartEmpty.style.display = 'none';
        cartWithItems.style.display = 'block';
        
        renderCartItems();
        updateCartTotals();
    }

    // Update cart count in header
    function updateCartCount() {
        const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
        cartCount.textContent = totalItems;
    }

    // Render cart items
    function renderCartItems() {
        cartItemsContainer.innerHTML = '';
        
        cartItems.forEach((item, index) => {
            const subtotal = item.price * item.quantity;
            
            const cartItemElement = document.createElement('div');
            cartItemElement.className = 'cart-item';
            cartItemElement.innerHTML = `
                <div class="cart-item-product">
                    <img src="${item.images[0]}" alt="${item.name}" class="cart-item-img">
                    <div class="cart-item-details">
                        <h3 class="cart-item-name">${item.name}</h3>
                        <p class="cart-item-category">${item.category}</p>
                    </div>
                </div>
                <div class="cart-item-price">₹${item.price.toLocaleString()}</div>
                <div class="cart-item-quantity">
                    <button class="quantity-btn minus-btn" data-index="${index}">-</button>
                    <input type="number" class="quantity-input" value="${item.quantity}" min="1" data-index="${index}">
                    <button class="quantity-btn plus-btn" data-index="${index}">+</button>
                </div>
                <div class="cart-item-subtotal">₹${subtotal.toLocaleString()}</div>
                <div class="cart-item-remove">
                    <button class="remove-item-btn" data-index="${index}">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
            
            cartItemsContainer.appendChild(cartItemElement);
        });
        
        // Add event listeners to quantity buttons
        document.querySelectorAll('.minus-btn').forEach(btn => {
            btn.addEventListener('click', decreaseQuantity);
        });
        
        document.querySelectorAll('.plus-btn').forEach(btn => {
            btn.addEventListener('click', increaseQuantity);
        });
        
        document.querySelectorAll('.quantity-input').forEach(input => {
            input.addEventListener('change', updateQuantity);
        });
        
        document.querySelectorAll('.remove-item-btn').forEach(btn => {
            btn.addEventListener('click', removeItem);
        });
    }

    // Update cart totals
    function updateCartTotals() {
        const subtotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
        const tax = subtotal * 0.18; // 18% tax
        const grandTotal = subtotal + tax;
        
        cartSubtotal.textContent = `₹${subtotal.toLocaleString()}`;
        cartTax.textContent = `₹${tax.toLocaleString()}`;
        cartGrandTotal.textContent = `₹${grandTotal.toLocaleString()}`;
    }

    // Decrease quantity
    function decreaseQuantity(e) {
        const index = e.target.getAttribute('data-index');
        if (cartItems[index].quantity > 1) {
            cartItems[index].quantity--;
            saveCart();
            updateCartUI();
        }
    }

    // Increase quantity
    function increaseQuantity(e) {
        const index = e.target.getAttribute('data-index');
        cartItems[index].quantity++;
        saveCart();
        updateCartUI();
    }

    // Update quantity from input
    function updateQuantity(e) {
        const index = e.target.getAttribute('data-index');
        const newQuantity = parseInt(e.target.value);
        
        if (newQuantity >= 1) {
            cartItems[index].quantity = newQuantity;
            saveCart();
            updateCartUI();
        } else {
            e.target.value = cartItems[index].quantity;
        }
    }

    // Remove item from cart
    function removeItem(e) {
        const index = e.currentTarget.getAttribute('data-index');
        cartItems.splice(index, 1);
        saveCart();
        updateCartUI();
    }

    // Clear cart
    clearCartBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to clear your cart?')) {
            cartItems = [];
            saveCart();
            updateCartUI();
        }
    });

    // Proceed to checkout
    checkoutBtn.addEventListener('click', () => {
        if (cartItems.length === 0) {
            alert('Your cart is empty!');
            return;
        }
        alert('Proceeding to checkout!');
        // In a real app, you would redirect to checkout page
    });

    // Save cart to localStorage
    function saveCart() {
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
    }
});