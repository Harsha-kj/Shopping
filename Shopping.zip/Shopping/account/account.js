document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const navItems = document.querySelectorAll('.settings-nav li');
    const tabs = document.querySelectorAll('.settings-tab');
    const changePasswordBtn = document.getElementById('changePasswordBtn');
    const passwordModal = document.getElementById('passwordModal');
    const closeModal = document.querySelector('.close-modal');
    const modalCancel = document.querySelector('.modal-cancel');
    const togglePasswordIcons = document.querySelectorAll('.toggle-password');
    const newPasswordInput = document.getElementById('newPassword');
    const confirmNewPasswordInput = document.getElementById('confirmNewPassword');
    const strengthBar = document.querySelector('.strength-bar');
    const strengthText = document.querySelector('.strength-text span');
    const themeOptions = document.querySelectorAll('input[name="theme"]');
    const logoutBtn = document.querySelector('.logout-btn');

    // Tab Navigation
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Update active nav item
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
            
            // Show corresponding tab
            tabs.forEach(tab => tab.classList.remove('active'));
            document.getElementById(tabId).classList.add('active');
        });
    });

    // Change Password Modal
    changePasswordBtn.addEventListener('click', function() {
        passwordModal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    });

    closeModal.addEventListener('click', function() {
        passwordModal.style.display = 'none';
        document.body.style.overflow = 'auto';
    });

    modalCancel.addEventListener('click', function() {
        passwordModal.style.display = 'none';
        document.body.style.overflow = 'auto';
    });

    // Close modal when clicking outside
    window.addEventListener('click', function(e) {
        if (e.target === passwordModal) {
            passwordModal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });

    // Toggle Password Visibility
    togglePasswordIcons.forEach(icon => {
        icon.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input');
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    });

    // Password Strength Checker
    if (newPasswordInput) {
        newPasswordInput.addEventListener('input', function() {
            const strength = checkPasswordStrength(this.value);
            updateStrengthIndicator(strength);
        });
    }

    // Theme Selection
    themeOptions.forEach(option => {
        option.addEventListener('change', function() {
            if (this.checked) {
                // In a real app, you would save this preference and apply the theme
                console.log('Theme changed to:', this.value);
            }
        });
    });

    // Logout Button
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            // In a real app, you would handle the logout process
            console.log('Logging out...');
            window.location.href = '/login.html';
        });
    }

    // Form Submissions
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show loading state
            const saveBtn = this.querySelector('.save-btn');
            if (saveBtn) {
                saveBtn.classList.add('loading');
                
                // Simulate form submission
                setTimeout(() => {
                    saveBtn.classList.remove('loading');
                    
                    // Show success message or handle response
                    if (this.id === 'passwordForm') {
                        passwordModal.style.display = 'none';
                        document.body.style.overflow = 'auto';
                        alert('Password changed successfully!');
                    } else {
                        alert('Settings saved successfully!');
                    }
                }, 1500);
            }
        });
    });

    // Helper Functions
    function checkPasswordStrength(password) {
        let strength = 0;
        
        // Length check
        if (password.length >= 8) strength += 1;
        if (password.length >= 12) strength += 1;
        
        // Character type checks
        if (/[A-Z]/.test(password)) strength += 1;
        if (/[0-9]/.test(password)) strength += 1;
        if (/[^A-Za-z0-9]/.test(password)) strength += 1;
        
        return Math.min(strength, 5); // Cap at 5
    }
    
    function updateStrengthIndicator(strength) {
        const width = (strength / 5) * 100;
        strengthBar.style.width = `${width}%`;
        
        // Update color and text based on strength
        if (strength <= 2) {
            strengthBar.style.backgroundColor = '#dc3545';
            strengthText.textContent = 'Weak';
        } else if (strength <= 3) {
            strengthBar.style.backgroundColor = '#fd7e14';
            strengthText.textContent = 'Medium';
        } else if (strength <= 4) {
            strengthBar.style.backgroundColor = '#ffc107';
            strengthText.textContent = 'Strong';
        } else {
            strengthBar.style.backgroundColor = '#28a745';
            strengthText.textContent = 'Very Strong';
        }
    }
});